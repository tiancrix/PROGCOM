from operator import truediv
import pygame, sys
from pygame import *
from pygame.locals import *
from random import randint

ancho=900
alto=500

pygame.init()
ventana=pygame.display.set_mode((300,300))

fuente=pygame.font.Font(None,30)
texto=fuente.render("¡Interactúa con R2D2! Utiliza las flechas en tu teclado para desplazarlo.",0,(100,60,60))
fuentesistema=pygame.font.SysFont("Arial",30)
textosistema=fuentesistema.render("Eliana Cortés",0,(200,60,80))


pygame.init()
ventana=pygame.display.set_mode((ancho,alto))
pygame.display.set_caption(("R2D2"))

pygame.mixer.init()
sonido_fondo = pygame.mixer.Sound("sonido.wav")
sonido_fondo = pygame.mixer.Sound("sonido.wav")
pygame.mixer.Sound.play(sonido_fondo,-1)

Imagen=pygame.image.load("imagen1.jpg")
posX=325
posY=180

velocidad=15
Blanco=(255,255,255)
derecha=True

while True:
    ventana.fill(Blanco)
    ventana.blit(Imagen,(posX,posY))

    for event in pygame.event.get():
        if event.type==QUIT:
            pygame.quit()
            sys.exit()
        elif event.type==pygame.KEYDOWN:
            if event.key==K_LEFT:
                posX-=velocidad
            elif event.key==K_RIGHT:
                posX+=velocidad
            elif event.key==K_UP:
                posY-=velocidad
            elif event.key==K_DOWN:
                posY+=velocidad

    ventana.blit(textosistema,(0,0))
    ventana.blit(texto,(100,100))

    pygame.display.update()